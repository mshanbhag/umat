package com.omnesys.mw.classes;

import java.io.Serializable;

public class CNESTNewsInfo implements Serializable
{
		 public int     iTransCode   = -1;
	     public String  sNewsMsg     =  "N/A";
	     public String  sExchSeg     =  "N/A";
	     public long    lSecondsSinceBoe = -1;
	     public long    lUsecs          = -1;

}
