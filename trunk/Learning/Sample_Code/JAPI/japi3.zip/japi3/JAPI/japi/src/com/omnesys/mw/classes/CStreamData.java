package com.omnesys.mw.classes;

import java.io.Serializable;

public class CStreamData implements Serializable
{
	public int    iMsgCode   = -1;
	public Object oStreamObj = null;

} // class CStreamData
