package com.omnesys.mw.classes;

import java.io.Serializable;

public class CSensexInfo implements Serializable
{
	public int    iValue	 = -1;
	public int    iOpenIndex  = -1;
	public int    iCloseIndex = -1;
	public long   lFeedTime   = -1;
	public String oName	  = null;
	public String oExchange   = null;

} // class CSensexInfo
