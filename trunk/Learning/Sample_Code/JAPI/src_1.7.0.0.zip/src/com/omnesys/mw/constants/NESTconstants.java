package com.omnesys.mw.constants;

public  class   NESTconstants
{
	public static final int NEST_MKTPIC = 1001;
	public static final int NEST_INDEX_INFO = 1002;
	public static final int NEST_NEWS_INFO  = 1003;
	public static final int NEST_DJ_NEWS_INFO  = 1004;
	public static final int NEST_BHAV_COPY = 1006;
	
	
	
	public static final int    UNSUB_NSE_MBO_MBP_INFO	    = 	466;
	public static final int    UNSUB_BSE_MBO_MBP_INFO	    = 	468;
	public static final int    UNSUB_NSE_FO_MBO_MBP_INFO    = 	470;
	public static final int    UNSUB_NCX_FO_MBO_MBP_INFO    = 	472;
	public static final int    UNSUB_MCX_FO_MBO_MBP_INFO    = 	474;
	public static final int    UNSUB_CFO_MBO_MBP_INFO       = 	476;
	
	
	public static final int    NSE_MBO_MBP_INFO		   = 465;
	public static final int    BSE_MBO_MBP_INFO		   = 467;
	public static final int    NSE_FO_MBO_MBP_INFO		= 469;
	public static final int    NCX_FO_MBO_MBP_INFO		= 471;
	public static final int    MCX_FO_MBO_MBP_INFO		= 473;
	public static final int    CFO_MBO_MBP_INFO	        = 475;
	
	public static final int    SUB_ALL_GIVEN_TOKENS        = 478;
	public static final int    UN_SUB_ALL_GIVEN_TOKENS     = 480;
	
}