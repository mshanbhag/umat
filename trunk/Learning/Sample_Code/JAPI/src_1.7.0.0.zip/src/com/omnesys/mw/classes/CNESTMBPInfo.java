package com.omnesys.mw.classes;

import java.io.Serializable;

public  class   CNESTMBPInfo  implements  Serializable
  {
	 public long  lQuantity;  
	 public long  lPrice;   
	 public short siNumberOfOrders;  
	 public short siBbBuySellFlag;

  }