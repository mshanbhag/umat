/*
 * Created on Aug 17, 2007
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.omnesys.mw.classes;

import java.io.Serializable;

/**
 * @author kaveri
 * 
 * TODO To change the template for this generated type comment go to Window -
 * Preferences - Java - Code Style - Code Templates
 */
public class CMarketStat implements Serializable
{
	public String sExch  = "NA";

	public String sNse   = "NA";
	public String sBse   = "NA";
	public String sNcdex = "NA";
	public String sNfo   = "NA";
	public String sMcx   = "NA";
	public String sCfo   = "NA";
	

}
